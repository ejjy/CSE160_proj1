#ifndef _PAIR_H_
#define _PAIR_H_
//typedef uint8_t pairType;


typedef struct pair{
	uint8_t src;
	uint8_t seq;
}pair;

#endif
